import logging
from aiogram import Bot, Dispatcher
from aiogram.contrib.fsm_storage.redis import RedisStorage2
from loguru import logger

from config import config
from handlers import register_all_handlers
from middlewares.throttling import ThrottlingMiddleware


async def on_startup(dp: Dispatcher):
    logger.info("Бот запущен")
    await dp.bot.set_my_commands([
        {"command": "start", "description": "Запустить бота"},
        {"command": "help", "description": "Помощь"},
    ])


async def on_shutdown(dp: Dispatcher):
    logger.info("Бот выключается")
    await dp.storage.close()
    await dp.storage.wait_closed()


def setup_logging():
    logging.basicConfig(level=logging.INFO)
    logger.add("logs/bot.log", rotation="10 MB", compression="zip")


def main():
    setup_logging()
    
    bot = Bot(token=config.BOT_TOKEN, parse_mode='HTML')
    storage = RedisStorage2.from_url(config.REDIS_URL)
    dp = Dispatcher(bot, storage=storage)
    
    # Регистрация middleware
    dp.middleware.setup(ThrottlingMiddleware())
    
    # Регистрация хэндлеров
    register_all_handlers(dp)
    
    # Запуск бота
    from aiogram import executor
    executor.start_polling(
        dp, 
        on_startup=on_startup, 
        on_shutdown=on_shutdown,
        skip_updates=True
    )


if __name__ == '__main__':
    main()