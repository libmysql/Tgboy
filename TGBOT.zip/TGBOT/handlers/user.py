from aiogram import types
from aiogram.dispatcher import FSMContext

from config import config
from keyboards.reply import get_main_menu
from loader import dp, db

@dp.message_handler(commands=['start', 'help'], state='*')
async def cmd_start(message: types.Message, state: FSMContext):
    await state.finish()
    
    text = (
        "👋 Добро пожаловать в наш магазин!\n\n"
        "Здесь вы можете приобрести различные товары.\n"
        "Используйте кнопки ниже для навигации по боту."
    )
    
    await message.answer(text, reply_markup=get_main_menu())

@dp.message_handler(text="📜 Политика конфиденциальности")
async def show_policy(message: types.Message):
    policy_text = (
        "🔒 <b>Политика конфиденциальности</b>\n\n"
        "1. Мы собираем только необходимые данные для обработки ваших заказов.\n"
        "2. Ваши платежные данные обрабатываются платежными системами и не хранятся у нас.\n"
        "3. Мы не передаем ваши данные третьим лицам.\n"
        "4. Вы можете запросить удаление ваших данных в любое время.\n\n"
        "По всем вопросам обращайтесь в поддержку."
    )
    await message.answer(policy_text)

@dp.message_handler(commands=['cart'])
async def cmd_cart(message: types.Message):
    from handlers.cart import view_cart
    msg = await message.answer("Загружаю вашу корзину...")
    await view_cart(types.CallbackQuery(message=msg))