from .user import *
from .products import *
from .support import *
from .profile import *
from .cart import *  # Добавляем новый обработчик