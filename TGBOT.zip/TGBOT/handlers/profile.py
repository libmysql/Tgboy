from aiogram import types
from aiogram.dispatcher import FSMContext

from keyboards.reply import get_main_menu
from keyboards.inline import 
from loader import dp


@dp.message_handler(text="👤 Профиль")
async def show_profile(message: types.Message):
    # Здесь должна быть логика получения данных пользователя из БД
    user_id = message.from_user.id
    username = message.from_user.full_name
    
    # Заглушка для данных пользователя
    orders_count = 0
    total_spent = 0
    cart_items = 0
    
    text = (
        f"👤 <b>Ваш профиль</b>\n\n"
        f"🆔 ID: <code>{user_id}</code>\n"
        f"📛 Имя: {username}\n\n"
        f"📊 Статистика:\n"
        f"🛒 Товаров в корзине: {cart_items}\n"
        f"📦 Заказов: {orders_count}\n"
        f"💰 Всего потрачено: {total_spent}₽"
    )
    
    await message.answer(text)