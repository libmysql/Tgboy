import json
from pathlib import Path
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import InputFile, InputMediaPhoto, PreCheckoutQuery, ContentType, Message

from config import config
from keyboards.inline import (
    categories_keyboard, 
    products_keyboard, 
    product_detail_keyboard,
    product_cb,
    back_to_products_keyboard
)
from loader import dp, db
from services.payment import generate_invoice, generate_cart_invoice

def load_products():
    if not config.PRODUCTS_JSON_PATH.exists():
        return {"categories": [], "products": []}
    
    with open(config.PRODUCTS_JSON_PATH, 'r', encoding='utf-8') as f:
        return json.load(f)

@dp.message_handler(text="🛍 Товары")
async def show_categories(message: types.Message):
    data = load_products()
    if not data['categories']:
        await message.answer("Категории товаров временно недоступны.")
        return
    
    await message.answer(
        "📂 Выберите категорию:",
        reply_markup=categories_keyboard(data['categories'])
    )

@dp.callback_query_handler(lambda c: c.data.startswith('category_'))
async def show_products(call: types.CallbackQuery):
    category_id = int(call.data.split('_')[1])
    data = load_products()
    
    products = [p for p in data['products'] if p['category_id'] == category_id]
    if not products:
        await call.answer("В этой категории пока нет товаров")
        return
    
    category_name = next(
        (cat['name'] for cat in data['categories'] if cat['id'] == category_id),
        "Товары"
    )
    
    await call.message.edit_text(
        f"🛒 Товары в категории <b>{category_name}</b>:",
        reply_markup=products_keyboard(data['products'], category_id)
    )
    await call.answer()

@dp.callback_query_handler(product_cb.filter(action='view'))
async def view_product(call: types.CallbackQuery, callback_data: dict):
    product_id = int(callback_data['id'])
    data = load_products()
    
    product = next((p for p in data['products'] if p['id'] == product_id), None)
    if not product:
        await call.answer("Товар не найден")
        return
    
    category_name = next(
        (cat['name'] for cat in data['categories'] if cat['id'] == product['category_id']),
        ""
    )
    
    text = (
        f"<b>{product['name']}</b>\n\n"
        f"📦 Категория: {category_name}\n"
        f"💰 Цена: {product['price']}₽\n"
        f"📝 Описание: {product.get('description', 'Нет описания')}\n\n"
        f"🆔 Артикул: {product['id']}"
    )
    
    cart = await db.get_cart(call.from_user.id)
    in_cart = str(product_id) in cart
    
    if product.get('image'):
        photo = InputMediaPhoto(
            media=InputFile(Path('data') / 'products' / product['image']),
            caption=text
        )
        await call.message.edit_media(
            photo,
            reply_markup=product_detail_keyboard(product_id, in_cart)
        )
    else:
        await call.message.edit_text(
            text,
            reply_markup=product_detail_keyboard(product_id, in_cart)
        )
    
    await call.answer()

@dp.callback_query_handler(product_cb.filter(action='add_to_cart'))
async def add_to_cart(call: types.CallbackQuery, callback_data: dict):
    product_id = int(callback_data['id'])
    await db.add_to_cart(call.from_user.id, product_id)
    await call.answer("Товар добавлен в корзину")
    await view_product(call, callback_data)

@dp.callback_query_handler(product_cb.filter(action='remove_from_cart'))
async def remove_from_cart(call: types.CallbackQuery, callback_data: dict):
    product_id = int(callback_data['id'])
    await db.remove_from_cart(call.from_user.id, product_id)
    await call.answer("Товар удален из корзины")
    await view_product(call, callback_data)

@dp.callback_query_handler(product_cb.filter(action='buy'))
async def process_buy_product(call: types.CallbackQuery, callback_data: dict):
    product_id = int(callback_data['id'])
    data = load_products()
    product = next((p for p in data['products'] if p['id'] == product_id), None)
    
    if not product:
        await call.answer("Товар не найден")
        return
    
    await call.answer()
    invoice = await generate_invoice(product, call.from_user.id)
    await call.message.answer_invoice(**invoice)

@dp.pre_checkout_query_handler()
async def process_pre_checkout(pre_checkout_query: PreCheckoutQuery):
    await dp.bot.answer_pre_checkout_query(
        pre_checkout_query_id=pre_checkout_query.id,
        ok=True
    )

@dp.message_handler(content_types=ContentType.SUCCESSFUL_PAYMENT)
async def process_successful_payment(message: Message):
    payment_info = message.successful_payment.to_python()
    user_id = message.from_user.id
    
    if payment_info['invoice_payload'].startswith('product_'):
        product_id = int(payment_info['invoice_payload'].split('_')[1])
        items = [{
            "product_id": product_id,
            "quantity": 1,
            "price": payment_info['total_amount'] / 100
        }]
    else:
        cart = await db.get_cart(user_id)
        data = load_products()
        items = []
        
        for product_id, quantity in cart.items():
            product = next((p for p in data['products'] if p['id'] == int(product_id)), None)
            if product:
                items.append({
                    "product_id": product['id'],
                    "quantity": quantity,
                    "price": product['price']
                })
        
        await db.clear_cart(user_id)
    
    order_id = await db.create_order(
        user_id=user_id,
        items=items,
        total=payment_info['total_amount'] / 100
    )
    
    await message.answer(
        f"✅ Платеж на сумму {payment_info['total_amount'] / 100}₽ успешно проведен!\n"
        f"Номер вашего заказа: {order_id}\n\n"
        "Спасибо за покупку!"
    )

@dp.callback_query_handler(text="back_to_categories")
async def back_to_categories(call: types.CallbackQuery):
    data = load_products()
    await call.message.edit_text(
        "📂 Выберите категорию:",
        reply_markup=categories_keyboard(data['categories'])
    )
    await call.answer()

@dp.callback_query_handler(lambda c: c.data.startswith('back_to_products_'))
async def back_to_products(call: types.CallbackQuery):
    category_id = int(call.data.split('_')[-1])
    data = load_products()
    
    products = [p for p in data['products'] if p['category_id'] == category_id]
    if not products:
        await call.answer("В этой категории пока нет товаров")
        return
    
    category_name = next(
        (cat['name'] for cat in data['categories'] if cat['id'] == category_id),
        "Товары"
    )
    
    await call.message.edit_text(
        f"🛒 Товары в категории <b>{category_name}</b>:",
        reply_markup=products_keyboard(data['products'], category_id)
    )
    await call.answer()