from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup

from config import config
from keyboards.reply import get_cancel_menu, get_main_menu
from loader import dp, bot


class SupportStates(StatesGroup):
    waiting_for_support_message = State()


@dp.message_handler(text="🛟 Поддержка")
async def ask_support(message: types.Message):
    text = (
        "✉️ Напишите ваше сообщение для поддержки.\n"
        "Опишите подробно ваш вопрос или проблему, и мы обязательно вам ответим.\n\n"
        "Чтобы отменить отправку, нажмите кнопку 'Отмена'."
    )
    await message.answer(text, reply_markup=get_cancel_menu())
    await SupportStates.waiting_for_support_message.set()


@dp.message_handler(state=SupportStates.waiting_for_support_message, text="❌ Отмена")
async def cancel_support(message: types.Message, state: FSMContext):
    await state.finish()
    await message.answer("Отправка сообщения в поддержку отменена.", reply_markup=get_main_menu())


@dp.message_handler(state=SupportStates.waiting_for_support_message)
async def send_to_support(message: types.Message, state: FSMContext):
    user_id = message.from_user.id
    username = message.from_user.full_name
    user_text = message.text
    
    # Отправляем сообщение админам
    for admin_id in config.ADMIN_IDS:
        try:
            await bot.send_message(
                admin_id,
                f"✉️ <b>Новое сообщение в поддержку</b>\n\n"
                f"👤 Пользователь: {username} (ID: {user_id})\n"
                f"📝 Текст: {user_text}"
            )
        except Exception as e:
            print(f"Не удалось отправить сообщение админу {admin_id}: {e}")
    
    await message.answer(
        "✅ Ваше сообщение отправлено в поддержку. Мы ответим вам в ближайшее время.",
        reply_markup=get_main_menu()
    )
    await state.finish()