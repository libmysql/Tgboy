from aiogram import types
from aiogram.types import InputMediaPhoto
from pathlib import Path

from config import config
from keyboards.inline import get_cart_keyboard, product_cb, cart_cb
from loader import dp, db
from services.payment import generate_cart_invoice

@dp.callback_query_handler(text="view_cart")
async def view_cart(call: types.CallbackQuery):
    cart = await db.get_cart(call.from_user.id)
    if not cart:
        await call.answer("🛒 Ваша корзина пуста", show_alert=True)
        return
    
    data = load_products()
    cart_items = []
    total = 0
    
    for product_id, quantity in cart.items():
        product = next((p for p in data['products'] if p['id'] == int(product_id)), None)
        if product:
            cart_items.append({
                'product': product,
                'quantity': quantity
            })
            total += product['price'] * quantity
    
    text = "🛒 <b>Ваша корзина</b>\n\n"
    for item in cart_items:
        text += (
            f"▪ {item['product']['name']}\n"
            f"  Количество: {item['quantity']}\n"
            f"  Цена: {item['product']['price']}₽ x {item['quantity']} = "
            f"{item['product']['price'] * item['quantity']}₽\n\n"
        )
    
    text += f"\n<b>Итого: {total}₽</b>"
    
    await call.message.edit_text(
        text,
        reply_markup=get_cart_keyboard(cart_items)
    )
    await call.answer()

@dp.callback_query_handler(lambda c: c.data.startswith('cart_'))
async def change_cart_item(call: types.CallbackQuery):
    action, product_id = call.data.split('_')[2:]
    product_id = int(product_id)
    
    if action == 'increase':
        await db.add_to_cart(call.from_user.id, product_id)
    elif action == 'decrease':
        cart = await db.get_cart(call.from_user.id)
        if cart.get(str(product_id), 0) <= 1:
            await db.remove_from_cart(call.from_user.id, product_id)
        else:
            await db.add_to_cart(call.from_user.id, product_id, -1)
    elif action == 'remove':
        await db.remove_from_cart(call.from_user.id, product_id)
    
    await view_cart(call)

@dp.callback_query_handler(text="checkout_cart")
async def checkout_cart(call: types.CallbackQuery):
    cart = await db.get_cart(call.from_user.id)
    if not cart:
        await call.answer("🛒 Ваша корзина пуста", show_alert=True)
        return
    
    data = load_products()
    cart_items = []
    total = 0
    
    for product_id, quantity in cart.items():
        product = next((p for p in data['products'] if p['id'] == int(product_id)), None)
        if product:
            cart_items.append({
                'id': product['id'],
                'name': product['name'],
                'price': product['price'],
                'quantity': quantity
            })
            total += product['price'] * quantity
    
    invoice = await generate_cart_invoice(cart_items, call.from_user.id)
    await call.message.answer_invoice(**invoice)
    await call.answer()

def load_products():
    if not config.PRODUCTS_JSON_PATH.exists():
        return {"categories": [], "products": []}
    
    with open(config.PRODUCTS_JSON_PATH, 'r', encoding='utf-8') as f:
        return json.load(f)