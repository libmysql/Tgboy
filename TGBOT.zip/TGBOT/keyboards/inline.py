from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.callback_data import CallbackData

# Callback data для товаров
product_cb = CallbackData('product', 'id', 'action')
cart_cb = CallbackData('cart', 'action', 'product_id')

def categories_keyboard(categories: list) -> InlineKeyboardMarkup:
    buttons = []
    for category in categories:
        buttons.append([InlineKeyboardButton(
            text=category['name'],
            callback_data=f"category_{category['id']}"
        )])
    return InlineKeyboardMarkup(inline_keyboard=buttons)

def products_keyboard(products: list, category_id: int) -> InlineKeyboardMarkup:
    buttons = []
    for product in products:
        if product['category_id'] == category_id:
            buttons.append([InlineKeyboardButton(
                text=f"{product['name']} - {product['price']}₽",
                callback_data=product_cb.new(id=product['id'], action='view')
            )])
    
    buttons.append([InlineKeyboardButton(
        text="🔙 Назад к категориям",
        callback_data="back_to_categories"
    )])
    return InlineKeyboardMarkup(inline_keyboard=buttons)

def product_detail_keyboard(product_id: int, in_cart: bool = False) -> InlineKeyboardMarkup:
    buttons = []
    
    if in_cart:
        buttons.append([InlineKeyboardButton(
            text="➖ Удалить из корзины",
            callback_data=product_cb.new(id=product_id, action='remove_from_cart')
        )])
    else:
        buttons.append([InlineKeyboardButton(
            text="➕ Добавить в корзину",
            callback_data=product_cb.new(id=product_id, action='add_to_cart')
        )])
    
    buttons.append([InlineKeyboardButton(
        text="💰 Купить сейчас",
        callback_data=product_cb.new(id=product_id, action='buy')
    )])
    
    buttons.append([InlineKeyboardButton(
        text="🛒 Перейти в корзину",
        callback_data="view_cart"
    )])
    
    buttons.append([InlineKeyboardButton(
        text="🔙 Назад к товарам",
        callback_data=f"back_to_products_{product_id}"
    )])
    
    return InlineKeyboardMarkup(inline_keyboard=buttons)

def get_cart_keyboard(cart_items: list) -> InlineKeyboardMarkup:
    buttons = []
    
    for item in cart_items:
        product = item['product']
        buttons.extend([
            [
                InlineKeyboardButton(
                    text=f"➖ {product['name']}",
                    callback_data=cart_cb.new(action='decrease', product_id=product['id'])
                ),
                InlineKeyboardButton(
                    text=f"➕",
                    callback_data=cart_cb.new(action='increase', product_id=product['id'])
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"❌ Удалить {product['name']}",
                    callback_data=cart_cb.new(action='remove', product_id=product['id'])
                )
            ]
        ])
    
    buttons.extend([
        [
            InlineKeyboardButton(
                text="💳 Оформить заказ",
                callback_data="checkout_cart"
            )
        ],
        [
            InlineKeyboardButton(
                text="🔙 Продолжить покупки",
                callback_data="back_to_categories"
            )
        ]
    ])
    
    return InlineKeyboardMarkup(inline_keyboard=buttons)

def back_to_products_keyboard(category_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text="🔙 Назад к товарам",
            callback_data=f"back_to_products_{category_id}"
        )]
    ])