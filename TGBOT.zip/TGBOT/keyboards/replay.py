from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

def get_main_menu() -> ReplyKeyboardMarkup:
    buttons = [
        [KeyboardButton(text="🛍 Товары")],
        [KeyboardButton(text="👤 Профиль"), KeyboardButton(text="🛟 Поддержка")],
        [KeyboardButton(text="📜 Политика конфиденциальности")]
    ]
    return ReplyKeyboardMarkup(keyboard=buttons, resize_keyboard=True)


def get_cancel_menu() -> ReplyKeyboardMarkup:
    buttons = [
        [KeyboardButton(text="❌ Отмена")]
    ]
    return ReplyKeyboardMarkup(keyboard=buttons, resize_keyboard=True)