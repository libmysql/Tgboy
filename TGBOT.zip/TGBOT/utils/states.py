from aiogram.dispatcher.filters.state import State, StatesGroup


class Throttling(StatesGroup):
    throttling = State()


class SupportStates(StatesGroup):
    waiting_for_support_message = State()