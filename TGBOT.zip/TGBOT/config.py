import os
from dotenv import load_dotenv
from pathlib import Path

load_dotenv()

BASE_DIR = Path(__file__).parent

class Config:
    BOT_TOKEN = os.getenv('8497087152:AAFU702CTfsPa9PGBVVDThgxVhBLqQ19_q8')
    ADMIN_IDS = list(map(int, os.getenv('ADMIN_IDS', '').split(',')))
    REDIS_URL = os.getenv('REDIS_URL', 'redis://localhost:6379/0')
    
    # Настройки платежей
    PAYMENT_PROVIDER_TOKEN = os.getenv('5775769170:LIVE:TG_A1ObkEv0h4dm7XdJDfSRkS4A')
    
    # Пути к файлам
    PRODUCTS_JSON_PATH = BASE_DIR / 'data' / 'products.json'
    
config = Config()