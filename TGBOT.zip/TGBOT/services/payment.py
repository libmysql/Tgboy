from aiogram.types import LabeledPrice
from config import config

async def generate_invoice(product_data: dict, user_id: int):
    prices = [LabeledPrice(
        label=product_data['name'], 
        amount=int(product_data['price'] * 100)
    )]
    
    return {
        "title": product_data['name'],
        "description": product_data.get('description', ''),
        "payload": f"product_{product_data['id']}_user_{user_id}",
        "provider_token": config.PAYMENT_PROVIDER_TOKEN,
        "currency": "RUB",
        "prices": prices,
        "start_parameter": "payment",
        "need_name": True,
        "need_phone_number": True,
        "need_shipping_address": True,
        "is_flexible": True
    }

async def generate_cart_invoice(cart_items: list, user_id: int):
    prices = []
    description = []
    
    for item in cart_items:
        prices.append(LabeledPrice(
            label=f"{item['name']} (x{item['quantity']})",
            amount=int(item['price'] * 100 * item['quantity'])
        ))
        description.append(f"{item['name']} - {item['quantity']} шт.")
    
    return {
        "title": "Оплата корзины",
        "description": "\n".join(description),
        "payload": f"cart_payment_user_{user_id}",
        "provider_token": config.PAYMENT_PROVIDER_TOKEN,
        "currency": "RUB",
        "prices": prices,
        "start_parameter": "cart_payment",
        "need_name": True,
        "need_phone_number": True,
        "need_shipping_address": True,
        "is_flexible": True
    }