import json
from pathlib import Path
from typing import Optional, Dict, List, Union

from redis import Redis
from loguru import logger

from config import config


class Database:
    def __init__(self):
        self.redis = Redis.from_url(config.REDIS_URL)
        logger.info("Подключение к Redis установлено")
    
    async def get_user_data(self, user_id: int) -> Optional[Dict]:
        data = self.redis.get(f"user:{user_id}")
        return json.loads(data) if data else None
    
    async def update_user_data(self, user_id: int, data: Dict):
        self.redis.set(f"user:{user_id}", json.dumps(data))
    
    async def add_to_cart(self, user_id: int, product_id: int, quantity: int = 1):
        cart = await self.get_cart(user_id)
        cart[str(product_id)] = cart.get(str(product_id), 0) + quantity
        self.redis.set(f"cart:{user_id}", json.dumps(cart))
    
    async def remove_from_cart(self, user_id: int, product_id: int):
        cart = await self.get_cart(user_id)
        if str(product_id) in cart:
            del cart[str(product_id)]
            self.redis.set(f"cart:{user_id}", json.dumps(cart))
    
    async def get_cart(self, user_id: int) -> Dict[str, int]:
        data = self.redis.get(f"cart:{user_id}")
        return json.loads(data) if data else {}
    
    async def clear_cart(self, user_id: int):
        self.redis.delete(f"cart:{user_id}")
    
    async def create_order(self, user_id: int, items: List[Dict], total: float) -> str:
        order_id = self.redis.incr("order_id")
        order_data = {
            "id": order_id,
            "user_id": user_id,
            "items": items,
            "total": total,
            "status": "created"
        }
        self.redis.set(f"order:{order_id}", json.dumps(order_data))
        self.redis.lpush(f"user_orders:{user_id}", order_id)
        return order_id


db = Database()