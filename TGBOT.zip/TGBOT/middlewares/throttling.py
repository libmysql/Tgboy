from aiogram import types
from aiogram.dispatcher.middlewares import BaseMiddleware
from aiogram.dispatcher.handler import CancelHandler

from loader import dp
from utils.states import Throttling


class ThrottlingMiddleware(BaseMiddleware):
    def __init__(self, limit=0.5):
        self.limit = limit
        super().__init__()

    async def on_process_message(self, message: types.Message, data: dict):
        state = dp.current_state(chat=message.chat.id, user=message.from_user.id)
        state_name = await state.get_state()
        
        if state_name and 'throttling' in state_name:
            raise CancelHandler()
        
        await state.set_state(Throttling.throttling)
        await asyncio.sleep(self.limit)
        await state.reset_state()